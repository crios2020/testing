package ar.org.centro8.curso.java.proyectofinal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProyectofinalApplicationTests {

	@Test
	void contextLoads() {
	}

}
