package com.example.calculadora;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CalculadoraApplicationTests {

	@Test
	public void test1(){
		//Ejemplo1
		assertEquals(1, 1); //cuando los dos valores son iguales, la salida es verde
	}

	@Test
	public void test2(){
		//Ejemplo2
		assertEquals(1, 2); //cuando los dos valores son distintos, la salida es roja
	}

	@Test
	public void test3(){
		//Ejemplo2
		assertEquals(2+2, 4); //Verde
	}

	@Test
	public void test4(){
		//Ejemplo2
		assertEquals(2+2, 5); //Rojo
	}

	/**
	 * Test de método sumar, prueba de suma de elementos enteros
	 */
	@Test
	public void testSumarEnteros1(){
		Calculadora calculadora=new Calculadora();
		assertEquals(calculadora.sumar(2, 2),4);
	}

	@Test
	public void testSumarEnteros2(){
		Calculadora calculadora=new Calculadora();
		assertEquals(calculadora.sumar(20, 4),24);
	}

	@Test
	public void testSumarEnteros3(){
		Calculadora calculadora=new Calculadora();
		assertEquals(calculadora.sumar(10, 5),14);	//Prueba mal realizada
	}

	@Test
	public void testSumaParametrosNoNumericos(){
		Calculadora calculadora=new Calculadora();
		//No se puede enviar parámetros no numéricos
		//assertEquals(calculadora.sumar("hola","chau"), 0);
	}

	@Test
	public void testSumarElementoNeutro1(){
		Calculadora calculadora=new Calculadora();
		assertEquals(calculadora.sumar(10, 0), 10);
	}

	@Test
	public void testSumarElementoNeutro2(){
		Calculadora calculadora=new Calculadora();
		assertEquals(calculadora.sumar(0, 10), 10);
	}

	@Test
	public void testSumarElementoNeutro3(){
		Calculadora calculadora=new Calculadora();
		assertEquals(calculadora.sumar(0, 0), 0);
	}

	@Test
	public void testSumarDesbordamiento1(){
		Calculadora calculadora=new Calculadora();
		assertEquals(calculadora.sumar(2000000000, 2000000000), 4000000000d);
	}

	@Test
	public void testSumarDesbordamiento2(){
		Calculadora calculadora=new Calculadora();
		assertEquals(calculadora.sumar(-2000000000, -2000000000), -4000000000d);
	}

	@Test
	public void testSumarNumerosNoEnteros1(){
		Calculadora calculadora=new Calculadora();
		assertEquals(calculadora.sumar(3.5, 2.4), 5.9);
	}

	@Test
	public void testSumarNumerosNoEnteros2(){
		Calculadora calculadora=new Calculadora();
		assertEquals(calculadora.sumar(10.5, 5.5), 16);
	}

	@Test
	public void testSumarNumerosNegativos1(){
		Calculadora calculadora=new Calculadora();
		assertEquals(calculadora.sumar(-10, 5), -5);
	}

	@Test
	public void testSumarNumerosNegativos2(){
		Calculadora calculadora=new Calculadora();
		assertEquals(calculadora.sumar(-10, -5), -15);
	}

	@Test
	public void testCalculadoraArgumentosIncorrectos1(){
		try{
			Calculadora.main("2", "+", "2");
			assertEquals(true, true);
		}catch(Exception e){
			assertEquals(false, true);
		}
	}

	@Test
	public void testCalculadoraArgumentosIncorrectos2(){
		try{
			Calculadora.main("hola", "+", "chau");
			assertEquals(true, true);
		}catch(Exception e){
			assertEquals(false, true);
		}
	}

	@Test
	public void testCalculadoraArgumentosIncorrectos3(){
		try{
			Calculadora.main("2", "p", "2");
			assertEquals(true, true);
		}catch(Exception e){
			assertEquals(false, true);
		}
	}
}
